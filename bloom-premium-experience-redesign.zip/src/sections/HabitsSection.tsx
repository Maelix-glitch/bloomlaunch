import { motion } from "framer-motion";
import { Eyebrow, Reveal, staggerContainer, staggerItem } from "../components/Reveal";
import { PanelFrame } from "../components/PanelFrame";

const HABITS = [
  { label: "Sleep", glyph: "☾", color: "#8d7bf2" },
  { label: "Water", glyph: "◈", color: "#5fd6d6" },
  { label: "Movement", glyph: "✽", color: "#7fb88f" },
  { label: "Reading", glyph: "▤", color: "#e8b158" },
  { label: "Studying", glyph: "◔", color: "#5b8ff2" },
  { label: "Stillness", glyph: "◐", color: "#e191b3" },
];

export function HabitsSection() {
  return (
    <section id="habits" className="relative overflow-hidden bg-[#050506] py-28 sm:py-36">
      <div className="mx-auto max-w-3xl px-6 text-center">
        <Reveal>
          <Eyebrow>Track · Habits</Eyebrow>
          <h2 className="mt-5 font-display text-[2.3rem] leading-tight text-white sm:text-[3rem]">
            Small actions.
            <br />
            <span className="italic text-white/60">Compounded into transformation.</span>
          </h2>
          <p className="mx-auto mt-5 max-w-xl text-[0.98rem] text-white/50">
            Consistency, not intensity. Each habit you keep becomes part of today's ring — and
            part of the pattern Coach learns from.
          </p>
        </Reveal>
      </div>

      <motion.div
        variants={staggerContainer}
        initial="hidden"
        whileInView="show"
        viewport={{ once: true, amount: 0.3 }}
        className="mx-auto mt-14 grid max-w-3xl grid-cols-3 gap-4 px-6 sm:grid-cols-6"
      >
        {HABITS.map((h) => (
          <motion.div
            key={h.label}
            variants={staggerItem}
            whileHover={{ y: -6 }}
            className="flex flex-col items-center gap-3 rounded-2xl border border-white/10 bg-white/[0.02] py-6"
          >
            <span
              className="flex h-11 w-11 items-center justify-center rounded-full text-lg"
              style={{ color: h.color, boxShadow: `inset 0 0 0 1px ${h.color}55`, background: `${h.color}14` }}
            >
              {h.glyph}
            </span>
            <span className="text-[0.72rem] text-white/55">{h.label}</span>
          </motion.div>
        ))}
      </motion.div>

      <div className="mx-auto mt-20 max-w-3xl px-6">
        <PanelFrame tilt="right" glow="green" className="mx-auto">
          <div className="bg-[#08090b] px-8 py-8 text-white sm:px-10">
            <p className="text-[0.68rem] uppercase tracking-[0.2em] text-white/35">Habits · 45 day view</p>
            <h3 className="mt-2 font-display text-[1.5rem]">Consistency, visualized.</h3>
            <div className="mt-6 grid grid-cols-9 gap-[5px] sm:grid-cols-[repeat(15,minmax(0,1fr))]">
              {Array.from({ length: 45 }).map((_, i) => (
                <span
                  key={i}
                  className="h-3 w-3 rounded-[3px]"
                  style={{
                    background: i < 32 ? `rgba(127,184,143,${0.35 + (i / 45) * 0.6})` : "rgba(255,255,255,0.06)",
                  }}
                />
              ))}
            </div>
            <p className="mt-5 text-[0.82rem] text-white/45">32-day streak building toward your next milestone.</p>
          </div>
        </PanelFrame>
      </div>
    </section>
  );
}
