import { BloomGlyph } from "../components/Logo";
import { RevealScale } from "../components/Reveal";

export function FinalCTA() {
  return (
    <section id="cta" className="relative flex min-h-[80vh] items-center justify-center overflow-hidden bg-[#050506] py-32">
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(45%_45%_at_50%_45%,rgba(232,177,88,0.1),transparent_70%)]" />
      <RevealScale className="relative flex flex-col items-center px-6 text-center">
        <div className="relative mb-8 flex items-center justify-center">
          <div className="absolute h-32 w-32 animate-breathe rounded-full bg-[radial-gradient(circle,rgba(232,177,88,0.3),transparent_70%)]" />
          <BloomGlyph size={56} strokeWidth={10} glow />
        </div>
        <h2 className="font-display text-[2.6rem] italic leading-tight text-white sm:text-[3.6rem]">
          Ready to bloom?
        </h2>
        <p className="mt-5 max-w-sm text-[0.98rem] text-white/50">
          Your life, understood, guided, and gently kept — one ecosystem away.
        </p>
        <a
          href="#top"
          className="mt-9 rounded-full bg-white px-8 py-3.5 text-[0.9rem] font-medium text-black transition-transform hover:scale-[1.04]"
        >
          Enter Bloom
        </a>
      </RevealScale>
    </section>
  );
}
