import { StorySection } from "../components/StorySection";
import { CycleMock } from "../components/mocks/CycleMock";

export function CycleSection() {
  return (
    <StorySection
      id="cycle"
      eyebrow="Discover · Cycle"
      title={
        <>
          Recurring patterns,
          <br />
          <span className="italic text-white/60">read in advance.</span>
        </>
      }
      description="Every cycle you log sharpens the prediction. Phase, timing, and what tends to help — recalculated the moment your record changes, never assumed."
      insightLabel="Time · Cycles · Progress"
      insight="A 28.3-day average, held with 100% steadiness across five logged cycles — from your data alone."
      side="left"
      glow="violet"
      bg="#07070a"
    >
      <CycleMock />
    </StorySection>
  );
}
