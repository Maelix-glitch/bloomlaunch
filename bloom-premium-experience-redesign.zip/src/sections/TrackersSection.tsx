import { StorySection } from "../components/StorySection";
import { TrackersMock } from "../components/mocks/TrackersMock";

export function TrackersSection() {
  return (
    <StorySection
      id="trackers"
      eyebrow="Discover · Trackers"
      title={
        <>
          The measurable
          <br />
          <span className="italic text-white/60">side of you.</span>
        </>
      }
      description="Sleep, water, study, movement, energy, screen time — six signals, measured daily against goals you set. No estimates. No filling in blanks."
      insightLabel="Daily → Weekly → Monthly → Long term"
      insight="Every reading compounds — today's ring becomes this month's line, becomes your longest streak."
      side="right"
      glow="green"
    >
      <TrackersMock />
    </StorySection>
  );
}
