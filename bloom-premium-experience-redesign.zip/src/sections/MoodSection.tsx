import { StorySection } from "../components/StorySection";
import { MoodMock } from "../components/mocks/MoodMock";

export function MoodSection() {
  return (
    <StorySection
      id="mood"
      eyebrow="Understand · Mood"
      title={
        <>
          Feel it.
          <br />
          <span className="italic text-white/60">Understand it.</span>
        </>
      }
      description="One honest check-in a day. Bloom holds the emotional texture of your life so patterns can surface on their own — no forced positivity, no generic prompts."
      insightLabel="Mood → Data → Patterns → Insight"
      insight="Bloom doesn't just record how you feel. It learns when, why, and what tends to shift it."
      side="right"
      glow="gold"
    >
      <MoodMock />
    </StorySection>
  );
}
