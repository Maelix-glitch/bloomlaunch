interface LogoProps {
  size?: number;
  className?: string;
  glow?: boolean;
  strokeWidth?: number;
}

/**
 * The Bloom mark — a single ascending arch rendered in the brand's
 * signature green → gold gradient. Faithful to the source app icon:
 * a rounded arch on a near-black tile.
 */
export function BloomGlyph({ size = 40, className = "", glow = false, strokeWidth = 9 }: LogoProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 100 100"
      fill="none"
      className={className}
      style={glow ? { filter: "drop-shadow(0 0 18px rgba(232,177,88,0.35))" } : undefined}
      aria-hidden="true"
    >
      <defs>
        <linearGradient id="bloom-arch" x1="14" y1="70" x2="86" y2="70" gradientUnits="userSpaceOnUse">
          <stop offset="0" stopColor="#7fb88f" />
          <stop offset="0.55" stopColor="#cdbd7e" />
          <stop offset="1" stopColor="#e8b158" />
        </linearGradient>
      </defs>
      <path
        d="M16 72 C 30 30, 70 30, 84 72"
        stroke="url(#bloom-arch)"
        strokeWidth={strokeWidth}
        strokeLinecap="round"
        fill="none"
      />
    </svg>
  );
}

export function BloomMark({ size = 44, className = "" }: LogoProps) {
  return (
    <div
      className={`flex items-center justify-center rounded-[26%] bg-[#12141a] ring-1 ring-white/10 ${className}`}
      style={{ width: size, height: size }}
    >
      <BloomGlyph size={size * 0.62} strokeWidth={size * 0.09} />
    </div>
  );
}

export function BloomWordmark({ className = "" }: { className?: string }) {
  return (
    <div className={`flex items-center gap-2.5 ${className}`}>
      <BloomGlyph size={26} strokeWidth={6.5} />
      <span className="font-display text-[1.25rem] tracking-tight text-white">Bloom</span>
    </div>
  );
}
