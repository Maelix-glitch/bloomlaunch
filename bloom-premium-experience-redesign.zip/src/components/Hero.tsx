import { useRef } from "react";
import { motion, useScroll, useTransform, useSpring, type MotionValue } from "framer-motion";
import { BloomGlyph } from "./Logo";
import { useReducedMotion } from "../hooks/useReducedMotion";

const NODES = [
  { label: "Mood", x: -320, y: -120, color: "#e5867e" },
  { label: "Cycle", x: 300, y: -150, color: "#8d7bf2" },
  { label: "Habits", x: -360, y: 130, color: "#7fb88f" },
  { label: "Trackers", x: 340, y: 150, color: "#5b8ff2" },
  { label: "Coach", x: 0, y: -260, color: "#e8b158" },
  { label: "Rewards", x: 0, y: 250, color: "#e191b3" },
];

function EcosystemNode({
  node,
  spread,
  opacity,
  reduced,
}: {
  node: (typeof NODES)[number];
  spread: MotionValue<number>;
  opacity: MotionValue<number>;
  reduced: boolean;
}) {
  const x = useTransform(spread, (v) => node.x * v);
  const y = useTransform(spread, (v) => node.y * v);

  return (
    <motion.div
      style={reduced ? undefined : { opacity, x, y }}
      className="absolute flex flex-col items-center gap-2"
    >
      <div
        className="h-3 w-3 rounded-full sm:h-4 sm:w-4"
        style={{ background: node.color, boxShadow: `0 0 20px ${node.color}` }}
      />
      <span className="text-[0.65rem] uppercase tracking-[0.2em] text-white/50 sm:text-[0.72rem]">
        {node.label}
      </span>
    </motion.div>
  );
}

/**
 * Scroll-driven cinematic reveal. The Bloom mark is the origin point:
 * it activates, radiates energy, and the ecosystem's surfaces emerge
 * from it. Progress is fully scroll-controlled (and reversible) via
 * framer-motion's scroll-linked transforms - no autoplay, no frame
 * images to preload, GPU-friendly transform/opacity only.
 */
export function Hero() {
  const ref = useRef<HTMLDivElement>(null);
  const reduced = useReducedMotion();
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end end"] });
  const p = useSpring(scrollYProgress, { stiffness: 120, damping: 26, mass: 0.4 });

  // Stage 1 (0 - 0.28): logo activates, energy ring blooms
  const logoScale = useTransform(p, [0, 0.22, 0.55, 1], [0.86, 1.08, 0.72, 0.56]);
  const ringScale = useTransform(p, [0, 0.3, 0.6], [0.4, 2.6, 3.6]);
  const ringOpacity = useTransform(p, [0, 0.12, 0.35, 0.6], [0, 0.5, 0.22, 0]);
  const glowOpacity = useTransform(p, [0, 0.2, 0.5, 0.8], [0.35, 0.9, 0.5, 0.15]);

  // Stage 2 (0.25 - 0.75): ecosystem nodes emerge from the mark
  const nodesOpacity = useTransform(p, [0.28, 0.45, 0.82, 1], [0, 1, 1, 0]);
  const nodesSpread = useTransform(p, [0.28, 0.6], [0.05, 1]);

  // Stage 3 (0.55 - 1): copy + CTA settle in
  const textOpacity = useTransform(p, [0.62, 0.8], [0, 1]);
  const textY = useTransform(p, [0.62, 0.85], [40, 0]);
  const heroBgOpacity = useTransform(p, [0, 0.9, 1], [1, 1, 0.85]);

  return (
    <section id="hero" ref={ref} className="relative h-[340vh]">
      <div className="sticky top-0 flex h-screen w-full items-center justify-center overflow-hidden bg-[#050506]">
        <motion.div
          style={{ opacity: heroBgOpacity }}
          className="absolute inset-0 bg-[radial-gradient(70%_60%_at_50%_38%,rgba(232,177,88,0.08),transparent_65%)]"
        />
        <div className="bg-noise pointer-events-none absolute inset-0 opacity-40" />

        <div className="perspective-dramatic relative flex h-full w-full max-w-[1400px] items-center justify-center">
          <div className="relative flex scale-[0.48] items-center justify-center sm:scale-75 md:scale-100">
            {/* Energy ring */}
            <motion.div
              style={reduced ? undefined : { scale: ringScale, opacity: ringOpacity }}
              className="absolute h-56 w-56 rounded-full border border-[#e8b158]/40 sm:h-72 sm:w-72"
            />
            <motion.div
              style={reduced ? undefined : { scale: ringScale, opacity: ringOpacity }}
              className="absolute h-56 w-56 rounded-full border border-bloom-green/30 sm:h-72 sm:w-72"
            />

            {/* Ecosystem nodes emerging from the mark */}
            {NODES.map((n) => (
              <EcosystemNode key={n.label} node={n} spread={nodesSpread} opacity={nodesOpacity} reduced={reduced} />
            ))}

            {/* The Bloom mark - origin point of everything */}
            <motion.div
              style={reduced ? undefined : { scale: logoScale }}
              className="relative z-10 flex flex-col items-center"
            >
              <motion.div
                style={{ opacity: glowOpacity }}
                className="absolute h-44 w-44 rounded-full bg-[radial-gradient(circle,rgba(232,177,88,0.4),transparent_70%)] sm:h-56 sm:w-56"
              />
              <BloomGlyph size={92} strokeWidth={13} glow />
            </motion.div>
          </div>

          {/* Headline settles in as the ecosystem resolves */}
          <motion.div
            style={reduced ? { opacity: 1 } : { opacity: textOpacity, y: textY }}
            className="absolute bottom-[12%] left-0 right-0 z-20 flex flex-col items-center px-6 text-center"
          >
            <h1 className="font-display text-[2.6rem] italic leading-[1.05] text-white sm:text-[3.6rem]">
              Your life.
              <br />
              <span className="text-[#f3e6c9]">In bloom.</span>
            </h1>
            <p className="mt-5 max-w-md text-[0.95rem] text-white/55">
              Mood, cycle, habits, trackers, coaching and rewards - one intelligent ecosystem
              for becoming your best self.
            </p>
            <div className="mt-7 flex items-center gap-4">
              <a
                href="#ecosystem"
                className="rounded-full bg-white px-6 py-3 text-[0.85rem] font-medium text-black transition-transform hover:scale-[1.04]"
              >
                Explore Bloom
              </a>
              <a
                href="#story"
                className="rounded-full border border-white/20 px-6 py-3 text-[0.85rem] font-medium text-white/80 transition-colors hover:text-white"
              >
                See how it works
              </a>
            </div>
          </motion.div>
        </div>

        <div className="absolute bottom-6 left-1/2 z-10 -translate-x-1/2 text-[0.65rem] uppercase tracking-[0.3em] text-white/30">
          Scroll to enter
        </div>
      </div>
    </section>
  );
}
