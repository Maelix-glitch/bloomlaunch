import { Reveal } from "./Reveal";

const STEPS = ["Understand", "Track", "Discover", "Improve", "Guidance", "Consistency", "Progress", "Become"];

export function StoryPath() {
  return (
    <section id="story" className="relative border-y border-white/[0.06] bg-[#050506] py-10">
      <Reveal amount={0.5}>
        <div className="mx-auto flex max-w-5xl flex-wrap items-center justify-center gap-x-3 gap-y-3 px-6">
          {STEPS.map((step, i) => (
            <div key={step} className="flex items-center gap-3">
              <span className="text-[0.72rem] uppercase tracking-[0.2em] text-white/40">{step}</span>
              {i < STEPS.length - 1 && <span className="text-white/15">→</span>}
            </div>
          ))}
        </div>
      </Reveal>
    </section>
  );
}
