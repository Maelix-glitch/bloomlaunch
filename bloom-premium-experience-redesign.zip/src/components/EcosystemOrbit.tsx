import { BloomGlyph } from "./Logo";
import { Eyebrow, Reveal } from "./Reveal";

const RING_1 = [
  { label: "Mood", color: "#e5867e", angle: 0 },
  { label: "Cycle", color: "#8d7bf2", angle: 120 },
  { label: "Habits", color: "#7fb88f", angle: 240 },
];

const RING_2 = [
  { label: "Trackers", color: "#5b8ff2", angle: 30 },
  { label: "Coach", color: "#e8b158", angle: 150 },
  { label: "Rewards", color: "#e191b3", angle: 270 },
];

const RING_3 = [
  { label: "Atelier", color: "#c9a6f2", angle: 60 },
  { label: "Profile", color: "#7fd1c9", angle: 180 },
  { label: "Dashboard", color: "#e8e8e8", angle: 300 },
];

function OrbitRing({
  items,
  radius,
  duration,
  reverse = false,
}: {
  items: { label: string; color: string; angle: number }[];
  radius: number;
  duration: number;
  reverse?: boolean;
}) {
  return (
    <div
      className="absolute rounded-full border border-white/[0.06]"
      style={{ width: radius * 2, height: radius * 2 }}
    >
      <div
        className="absolute inset-0"
        style={{ animation: `${reverse ? "orbit-rev" : "orbit"} ${duration}s linear infinite` }}
      >
        {items.map((item) => (
          <div
            key={item.label}
            className="absolute left-1/2 top-1/2 flex flex-col items-center gap-2"
            style={{
              transform: `rotate(${item.angle}deg) translate(${radius}px) rotate(-${item.angle}deg)`,
            }}
          >
            <div
              className="flex items-center justify-center rounded-2xl border border-white/10 bg-white/[0.03] px-4 py-2.5 backdrop-blur-sm"
              style={{ animation: `${reverse ? "orbit" : "orbit-rev"} ${duration}s linear infinite`, boxShadow: `0 0 24px -6px ${item.color}88` }}
            >
              <span className="whitespace-nowrap text-[0.72rem] font-medium tracking-wide" style={{ color: item.color }}>
                {item.label}
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export function EcosystemOrbit() {
  return (
    <section id="ecosystem" className="relative overflow-hidden bg-[#050506] py-32 sm:py-44">
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(50%_50%_at_50%_50%,rgba(141,123,242,0.06),transparent_70%)]" />

      <div className="relative mx-auto max-w-3xl px-6 text-center">
        <Reveal>
          <Eyebrow>The bloom ecosystem</Eyebrow>
          <h2 className="mt-5 font-display text-[2.4rem] leading-tight text-white sm:text-[3.2rem]">
            Everything about you,
            <br />
            <span className="italic text-white/60">connected.</span>
          </h2>
          <p className="mx-auto mt-5 max-w-lg text-[0.98rem] text-white/50">
            Mood, cycle, habits, trackers, coaching, rewards, identity and progress — nine
            surfaces orbiting a single, intelligent core.
          </p>
        </Reveal>
      </div>

      <div className="relative mx-auto mt-20 hidden h-[640px] max-w-5xl items-center justify-center md:flex">
        <OrbitRing items={RING_3} radius={300} duration={70} reverse />
        <OrbitRing items={RING_2} radius={220} duration={52} />
        <OrbitRing items={RING_1} radius={140} duration={38} reverse />
        <div className="relative z-10 flex h-24 w-24 items-center justify-center rounded-full bg-[#0c0d11] ring-1 ring-white/10">
          <div className="absolute h-32 w-32 animate-breathe rounded-full bg-[radial-gradient(circle,rgba(232,177,88,0.28),transparent_70%)]" />
          <BloomGlyph size={44} strokeWidth={9} />
        </div>
      </div>

      {/* Mobile-friendly stacked version */}
      <div className="relative mx-auto mt-14 grid max-w-md grid-cols-3 gap-3 px-6 md:hidden">
        {[...RING_1, ...RING_2, ...RING_3].map((item) => (
          <div
            key={item.label}
            className="flex flex-col items-center gap-2 rounded-xl border border-white/10 bg-white/[0.03] py-4"
          >
            <span className="h-2 w-2 rounded-full" style={{ background: item.color, boxShadow: `0 0 10px ${item.color}` }} />
            <span className="text-[0.72rem] text-white/70">{item.label}</span>
          </div>
        ))}
      </div>
    </section>
  );
}
