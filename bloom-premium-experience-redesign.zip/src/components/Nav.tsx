import { useEffect, useState } from "react";
import { BloomGlyph } from "./Logo";

const LINKS = [
  { href: "#ecosystem", label: "Ecosystem" },
  { href: "#mood", label: "Mood" },
  { href: "#cycle", label: "Cycle" },
  { href: "#coach", label: "Coach" },
  { href: "#rewards", label: "Rewards" },
  { href: "#dashboard", label: "Dashboard" },
];

export function Nav() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-all duration-500 ${
        scrolled ? "border-b border-white/[0.06] bg-black/60 backdrop-blur-xl" : "bg-transparent"
      }`}
    >
      <div className="mx-auto flex max-w-[1400px] items-center justify-between px-6 py-4 sm:px-10">
        <a href="#top" className="flex items-center gap-2.5">
          <BloomGlyph size={24} strokeWidth={6} />
          <span className="font-display text-[1.1rem] tracking-tight text-white">Bloom</span>
        </a>

        <nav className="hidden items-center gap-8 lg:flex">
          {LINKS.map((l) => (
            <a
              key={l.href}
              href={l.href}
              className="text-[0.82rem] font-medium text-white/55 transition-colors hover:text-white"
            >
              {l.label}
            </a>
          ))}
        </nav>

        <div className="hidden items-center gap-4 lg:flex">
          <a href="#cta" className="text-[0.82rem] font-medium text-white/60 hover:text-white">
            Sign in
          </a>
          <a
            href="#cta"
            className="rounded-full bg-white px-4 py-2 text-[0.82rem] font-medium text-black transition-transform hover:scale-[1.03]"
          >
            Enter Bloom
          </a>
        </div>

        <button
          aria-label="Toggle menu"
          className="flex h-9 w-9 items-center justify-center rounded-full border border-white/15 text-white lg:hidden"
          onClick={() => setOpen((v) => !v)}
        >
          <span className="text-lg leading-none">{open ? "×" : "≡"}</span>
        </button>
      </div>

      {open && (
        <div className="border-t border-white/[0.06] bg-black/95 px-6 py-6 lg:hidden">
          <nav className="flex flex-col gap-4">
            {LINKS.map((l) => (
              <a key={l.href} href={l.href} className="text-[0.95rem] text-white/70" onClick={() => setOpen(false)}>
                {l.label}
              </a>
            ))}
            <a href="#cta" className="mt-2 rounded-full bg-white px-4 py-2.5 text-center text-[0.9rem] font-medium text-black">
              Enter Bloom
            </a>
          </nav>
        </div>
      )}
    </header>
  );
}
