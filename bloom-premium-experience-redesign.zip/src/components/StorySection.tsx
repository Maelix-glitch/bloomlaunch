import type { ReactNode } from "react";
import { Eyebrow, Reveal } from "./Reveal";
import { PanelFrame } from "./PanelFrame";

export function StorySection({
  id,
  eyebrow,
  title,
  description,
  insightLabel,
  insight,
  side = "right",
  glow = "gold",
  bg,
  children,
}: {
  id: string;
  eyebrow: string;
  title: ReactNode;
  description: string;
  insightLabel: string;
  insight: string;
  side?: "left" | "right";
  glow?: "gold" | "violet" | "pink" | "green";
  bg?: string;
  children: ReactNode;
}) {
  const copy = (
    <Reveal className="max-w-md" y={22}>
      <Eyebrow>{eyebrow}</Eyebrow>
      <h2 className="mt-5 font-display text-[2.1rem] leading-[1.12] text-white sm:text-[2.6rem]">{title}</h2>
      <p className="mt-5 text-[0.98rem] leading-relaxed text-white/55">{description}</p>
      <div className="mt-7 border-t border-white/10 pt-5">
        <p className="text-[0.68rem] uppercase tracking-[0.22em] text-white/35">{insightLabel}</p>
        <p className="mt-2 text-[0.92rem] text-white/70">{insight}</p>
      </div>
    </Reveal>
  );

  const visual = (
    <PanelFrame tilt={side === "right" ? "left" : "right"} glow={glow} className="w-full">
      {children}
    </PanelFrame>
  );

  return (
    <section
      id={id}
      className="relative overflow-hidden py-28 sm:py-36"
      style={{ background: bg ?? "#050506" }}
    >
      <div className="mx-auto grid max-w-[1300px] items-center gap-14 px-6 lg:grid-cols-[0.85fr_1.15fr] lg:gap-20 lg:px-10">
        {side === "right" ? (
          <>
            {copy}
            {visual}
          </>
        ) : (
          <>
            <div className="lg:order-2">{copy}</div>
            <div className="lg:order-1">{visual}</div>
          </>
        )}
      </div>
    </section>
  );
}
