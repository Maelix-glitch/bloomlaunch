import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { BloomGlyph } from "./Logo";
import { useReducedMotion } from "../hooks/useReducedMotion";

export function Preloader({ onDone }: { onDone: () => void }) {
  const [visible, setVisible] = useState(true);
  const reduced = useReducedMotion();

  useEffect(() => {
    const total = reduced ? 300 : 2200;
    const t = setTimeout(() => setVisible(false), total);
    return () => clearTimeout(t);
  }, [reduced]);

  return (
    <AnimatePresence onExitComplete={onDone}>
      {visible && (
        <motion.div
          className="fixed inset-0 z-[100] flex items-center justify-center bg-[#050506]"
          exit={{ opacity: 0 }}
          transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.85 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1.1, ease: [0.16, 1, 0.3, 1] }}
            className="relative flex flex-col items-center"
          >
            <motion.div
              className="absolute h-40 w-40 rounded-full"
              style={{ background: "radial-gradient(circle, rgba(232,177,88,0.25), transparent 70%)" }}
              animate={reduced ? undefined : { scale: [1, 1.35, 1], opacity: [0.5, 0.9, 0.5] }}
              transition={{ duration: 2.4, repeat: Infinity, ease: "easeInOut" }}
            />
            <BloomGlyph size={64} strokeWidth={11} glow />
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.5 }}
              transition={{ delay: 0.9, duration: 0.8 }}
              className="mt-6 text-[0.7rem] uppercase tracking-[0.4em] text-white/50"
            >
              Entering Bloom
            </motion.p>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
