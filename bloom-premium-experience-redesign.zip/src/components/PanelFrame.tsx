import { motion } from "framer-motion";
import type { ReactNode } from "react";

const EASE = [0.16, 1, 0.3, 1] as const;

/**
 * A dimensional glass/metal surface used to present the real Bloom
 * product UI. Adds depth via perspective + tilt without altering the
 * interface content it wraps.
 */
export function PanelFrame({
  children,
  tilt = "left",
  glow = "gold",
  className = "",
}: {
  children: ReactNode;
  tilt?: "left" | "right" | "none";
  glow?: "gold" | "violet" | "pink" | "green";
  className?: string;
}) {
  const rotate =
    tilt === "left" ? { rotateY: 6, rotateX: 2 } : tilt === "right" ? { rotateY: -6, rotateX: 2 } : { rotateY: 0, rotateX: 0 };

  const glowColor = {
    gold: "rgba(232,177,88,0.18)",
    violet: "rgba(141,123,242,0.2)",
    pink: "rgba(225,145,179,0.18)",
    green: "rgba(127,184,143,0.18)",
  }[glow];

  return (
    <div className={`perspective-dramatic ${className}`}>
      <motion.div
        initial={{ opacity: 0, y: 60, ...rotate, scale: 0.96 }}
        whileInView={{ opacity: 1, y: 0, rotateY: rotate.rotateY * 0.55, rotateX: rotate.rotateX * 0.55, scale: 1 }}
        viewport={{ once: true, amount: 0.2 }}
        transition={{ duration: 1.2, ease: EASE }}
        style={{ transformStyle: "preserve-3d" }}
        className="relative"
      >
        <div
          className="absolute -inset-6 rounded-[2rem] blur-3xl -z-10"
          style={{ background: `radial-gradient(60% 60% at 50% 40%, ${glowColor}, transparent 70%)` }}
        />
        <div className="relative rounded-2xl border border-white/10 bg-[#08090c] shadow-[0_40px_120px_-30px_rgba(0,0,0,0.9)] overflow-hidden">
          <div className="flex items-center gap-1.5 border-b border-white/[0.06] bg-white/[0.02] px-4 py-2.5">
            <span className="h-2.5 w-2.5 rounded-full bg-white/10" />
            <span className="h-2.5 w-2.5 rounded-full bg-white/10" />
            <span className="h-2.5 w-2.5 rounded-full bg-white/10" />
          </div>
          <div className="relative">{children}</div>
          <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/10 via-transparent to-white/[0.03]" />
        </div>
      </motion.div>
    </div>
  );
}

export function MacBookFrame({ children }: { children: ReactNode }) {
  return (
    <div className="relative mx-auto w-full max-w-[1100px]" style={{ transformStyle: "preserve-3d" }}>
      <div className="relative rounded-t-[1.1rem] border-[6px] border-b-0 border-[#1c1d22] bg-[#08090c] p-[10px] shadow-[0_60px_160px_-40px_rgba(0,0,0,0.95)]">
        <div className="absolute left-1/2 top-1 h-1.5 w-1.5 -translate-x-1/2 rounded-full bg-black/60" />
        <div className="overflow-hidden rounded-[0.5rem] border border-white/5 bg-black">{children}</div>
      </div>
      <div className="relative h-[16px] rounded-b-[0.6rem] bg-gradient-to-b from-[#232429] to-[#101114]">
        <div className="absolute left-1/2 top-0 h-[6px] w-[16%] -translate-x-1/2 rounded-b-xl bg-[#0a0a0c]" />
      </div>
      <div className="mx-auto h-[7px] w-[55%] rounded-b-2xl bg-gradient-to-b from-[#17181c] to-[#08090a]" />
    </div>
  );
}
