import { AppShell } from "./AppShell";

const FACES = [
  { label: "Happy", emoji: "🙂", active: false },
  { label: "Calm", emoji: "😌", active: true },
  { label: "Neutral", emoji: "😐", active: false },
  { label: "Sad", emoji: "🙁", active: false },
  { label: "Anxious", emoji: "😧", active: false },
  { label: "Angry", emoji: "😠", active: false },
];

export function MoodMock() {
  return (
    <AppShell active="Mood">
      <div className="relative overflow-hidden px-6 py-6 sm:px-10 sm:py-8">
        <div className="pointer-events-none absolute inset-0 bg-gradient-to-br from-[#1a1710]/40 via-transparent to-transparent" />
        <div className="relative flex items-center justify-between text-[0.8rem] text-white/40">
          <span>Thu, September 17</span>
          <div className="flex items-center gap-3">
            <span>🔔</span>
            <span className="flex h-7 w-7 items-center justify-center rounded-full bg-white/10 text-[0.7rem]">B</span>
          </div>
        </div>

        <div className="relative mt-6 flex flex-col justify-between gap-8 sm:flex-row sm:items-end">
          <div>
            <p className="text-[0.68rem] uppercase tracking-[0.2em] text-white/35">
              Mood tracker · Thursday, September 17, 2026
            </p>
            <h2 className="mt-3 font-display text-[2.3rem] leading-[1.1] text-white sm:text-[2.8rem]">
              Today you feel <span className="italic text-[#f3e6c9]">calm.</span>
            </h2>
            <p className="mt-3 max-w-md text-[0.88rem] text-white/50">
              Logged at 9:23 AM with a note.{" "}
              <span className="text-[#e8b158]">Refine it</span> or <span className="text-[#e8b158]">add another</span>.
            </p>
          </div>
          <p className="font-display text-right text-[1.1rem] italic leading-relaxed text-white/70">
            Feel it.
            <br />
            Understand it.
            <br />
            Grow from it.
          </p>
        </div>

        <div className="relative mt-8 rounded-2xl border border-white/[0.07] bg-white/[0.015] p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-[0.95rem]">✦ Log your mood</p>
              <p className="mt-1 text-[0.8rem] text-white/45">Take a moment. Be honest with yourself.</p>
            </div>
            <span className="rounded-full bg-gradient-to-r from-[#e8b158] to-[#f0cf8e] px-5 py-2.5 text-[0.82rem] font-medium text-black">
              + Log an entry
            </span>
          </div>
          <div className="mt-6 flex flex-wrap justify-between gap-4">
            {FACES.map((f) => (
              <div key={f.label} className="flex flex-col items-center gap-2">
                <div
                  className={`flex h-16 w-16 items-center justify-center rounded-full text-2xl ${
                    f.active ? "bg-[#c8e2c4] ring-4 ring-[#e8b158]/50" : "bg-white/[0.06]"
                  }`}
                >
                  {f.emoji}
                </div>
                <span className={`text-[0.75rem] ${f.active ? "text-[#e8b158]" : "text-white/45"}`}>{f.label}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </AppShell>
  );
}
