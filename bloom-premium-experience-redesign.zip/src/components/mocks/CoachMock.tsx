import { AppShell } from "./AppShell";

export function CoachMock() {
  return (
    <AppShell active="Coach" minHeight={640}>
      <div className="flex h-full min-h-[620px] flex-col">
        <div className="flex items-center justify-between border-b border-white/[0.06] px-6 py-4 sm:px-8">
          <div>
            <p className="flex items-center gap-2 text-[0.95rem]">
              Bloom Coach <span className="h-1.5 w-1.5 rounded-full bg-bloom-green" />
            </p>
            <p className="text-[0.75rem] text-white/40">Your personal wellbeing companion</p>
          </div>
          <span className="rounded-full border border-white/10 px-3 py-1.5 text-[0.72rem] text-bloom-green">
            Personal context · On
          </span>
        </div>

        <div className="flex-1 space-y-5 overflow-hidden px-6 py-6 text-[0.85rem] leading-relaxed sm:px-8">
          <div className="ml-auto max-w-md rounded-2xl rounded-tr-sm bg-white/[0.08] px-4 py-2.5 text-white/85">
            Is my energy affected by any of this?
          </div>

          <div className="max-w-xl space-y-3">
            <p className="text-white/40">Bloom · 09:01 PM</p>
            <p className="text-white/85">Yes — energy is the most connected signal in your record.</p>
            <ol className="list-decimal space-y-1 pl-5 text-white/75">
              <li>
                <span className="font-medium text-white">Sleep quality → Energy</span> (r = 0.71)
              </li>
              <li>
                <span className="font-medium text-white">Movement → Energy</span> (r = 0.58)
              </li>
              <li>
                <span className="font-medium text-white">Screen time → Energy</span> (r = -0.44)
              </li>
            </ol>
            <p className="text-white/60">
              On your best energy days you averaged 7.5h sleep, 45min movement, and under 2.5h screen.
            </p>
            <p className="text-[0.72rem] text-bloom-violet/80">
              ✦ From your record — Energy correlations · Best-day analysis · Tracker connections
            </p>
          </div>

          <div className="flex flex-wrap gap-2 pt-2">
            {["What's draining me?", "Help me plan around my energy", "Look for a pattern"].map((s) => (
              <span key={s} className="rounded-full border border-white/12 px-4 py-2 text-[0.78rem] text-white/60">
                {s}
              </span>
            ))}
          </div>
        </div>

        <div className="border-t border-white/[0.06] px-6 py-4 sm:px-8">
          <div className="flex items-center justify-between rounded-full border border-white/10 bg-white/[0.03] px-5 py-3 text-[0.85rem] text-white/35">
            What are you thinking about?
            <span className="text-white/50">➤</span>
          </div>
        </div>
      </div>
    </AppShell>
  );
}
