import { AppShell, Card, StatChip } from "./AppShell";

export function TodayMock() {
  return (
    <AppShell active="Today">
      <div className="px-6 py-6 sm:px-10 sm:py-8">
        <div className="mb-6 flex items-center justify-between text-[0.8rem] text-white/40">
          <span>Thu, September 17</span>
          <span className="flex h-7 w-7 items-center justify-center rounded-full border border-white/10">🔔</span>
        </div>

        <h2 className="font-display text-[2.1rem] italic text-[#f3e6c9] sm:text-[2.6rem]">Good morning.</h2>
        <p className="mt-1 max-w-lg text-[0.95rem] text-white/55">
          Everything you track is logged. Enjoy the quiet.
        </p>

        <div className="mt-5 flex flex-wrap gap-2.5">
          <StatChip>☺ Mood 8/10 logged</StatChip>
          <StatChip>◔ 6 of 6 goals met</StatChip>
          <StatChip>✦ Your journey</StatChip>
        </div>

        <Card className="mt-7">
          <p className="text-[0.68rem] uppercase tracking-[0.2em] text-white/35">Habits</p>
          <div className="mt-1 flex flex-wrap items-start justify-between gap-3">
            <div>
              <h3 className="font-display text-[1.4rem]">Your habits today</h3>
              <p className="mt-1 text-[0.85rem] text-white/50">Small routines that shape the day — add your first one.</p>
            </div>
            <span className="rounded-full border border-white/15 px-4 py-2 text-[0.8rem] text-white/70">+ Add habit</span>
          </div>
          <div className="mt-5 flex flex-wrap items-center justify-between gap-4 rounded-xl border border-dashed border-white/15 px-5 py-5">
            <div>
              <p className="text-[0.95rem]">No habits yet.</p>
              <p className="mt-1 max-w-md text-[0.82rem] text-white/45">
                Add one small routine. It becomes part of today's ring, earns points when you tick it, and the Coach starts noticing it.
              </p>
            </div>
            <span className="whitespace-nowrap rounded-full bg-gradient-to-r from-bloom-violet to-[#b28ef2] px-5 py-2.5 text-[0.82rem] font-medium text-white">
              + Add your first habit
            </span>
          </div>
        </Card>

        <div className="mt-5 grid gap-5 sm:grid-cols-[0.85fr_1.3fr_0.9fr]">
          <Card>
            <p className="text-[0.95rem]">Today's progress</p>
            <div className="mt-5 flex justify-center">
              <div className="relative flex h-32 w-32 items-center justify-center rounded-full bg-[conic-gradient(from_-40deg,#e191b3_0%,#8d7bf2_82%,rgba(255,255,255,0.08)_82%)]">
                <div className="flex h-24 w-24 flex-col items-center justify-center rounded-full bg-[#0b0c0f]">
                  <span className="text-xl font-semibold">91%</span>
                </div>
              </div>
            </div>
            <p className="mt-3 text-center text-[0.72rem] text-white/40">of what's logged so far</p>
          </Card>
          <Card>
            <div className="flex items-center justify-between">
              <p className="text-[0.95rem]">Your connection map</p>
              <span className="rounded-full border border-white/10 px-3 py-1 text-[0.7rem] text-white/45">Last 30 days</span>
            </div>
            <div className="relative mt-6 flex h-32 items-center justify-center gap-10">
              <div className="flex flex-col items-center gap-1">
                <div className="flex h-11 w-11 items-center justify-center rounded-full ring-1 ring-bloom-blue/60 text-bloom-blue">☾</div>
                <span className="text-[0.68rem] text-white/40">Sleep 100%</span>
              </div>
              <div className="flex flex-col items-center gap-1 -mt-6">
                <div className="flex h-12 w-12 items-center justify-center rounded-full ring-1 ring-[#e5867e]/70 text-[#e5867e]">☺</div>
                <span className="text-[0.68rem] text-white/40">Mood 91%</span>
              </div>
              <div className="flex flex-col items-center gap-1">
                <div className="flex h-11 w-11 items-center justify-center rounded-full ring-1 ring-bloom-green/60 text-bloom-green">✽</div>
                <span className="text-[0.68rem] text-white/40">Habits 0%</span>
              </div>
            </div>
          </Card>
          <Card>
            <p className="text-[0.95rem]">Today's focus</p>
            <p className="mt-3 text-[0.82rem] leading-relaxed text-white/50">
              Everything you track is logged for today. Nothing left to chase.
            </p>
            <div className="mt-5 border-t border-white/[0.06] pt-4">
              <p className="text-[0.8rem] text-white/70">◎ Coach</p>
              <p className="mt-1 text-[0.75rem] text-white/40">Open →</p>
            </div>
          </Card>
        </div>
      </div>
    </AppShell>
  );
}
