import type { ReactNode } from "react";
import { BloomGlyph } from "../Logo";

const NAV = [
  { label: "Today", icon: "▦" },
  { label: "Trackers", icon: "⌁" },
  { label: "Cycle", icon: "◔" },
  { label: "Mood", icon: "☺" },
  { label: "Rewards", icon: "▣" },
  { label: "Coach", icon: "◎" },
];

/**
 * Faithful recreation of the real Bloom application chrome: dark
 * sidebar, wordmark, nav items, and the signature "A calmer you, a
 * brighter tomorrow." footer card. Used as the shell for every
 * product screenshot recreation in this site.
 */
export function AppShell({
  active,
  children,
  minHeight = 620,
}: {
  active: string;
  children: ReactNode;
  minHeight?: number;
}) {
  return (
    <div className="flex w-full bg-[#08090b] text-white" style={{ minHeight }}>
      <aside className="hidden w-[220px] shrink-0 flex-col justify-between border-r border-white/[0.06] bg-[#0a0b0e] px-5 py-6 sm:flex">
        <div>
          <div className="mb-8 flex items-center gap-2.5 px-1">
            <BloomGlyph size={22} strokeWidth={6} />
            <span className="font-display text-[1.05rem]">Bloom</span>
          </div>
          <nav className="space-y-1">
            {NAV.map((item) => (
              <div
                key={item.label}
                className={`flex items-center gap-3 rounded-lg px-3 py-2 text-[0.85rem] ${
                  item.label === active
                    ? "bg-white/[0.06] text-white ring-1 ring-white/10"
                    : "text-white/45"
                }`}
              >
                <span className="w-4 text-center text-[0.8rem] opacity-70">{item.icon}</span>
                {item.label}
              </div>
            ))}
          </nav>
          <div className="mt-4 border-t border-white/[0.06] pt-4">
            <div className="flex items-center gap-3 rounded-lg px-3 py-2 text-[0.85rem] text-white/45">
              <span className="w-4 text-center text-[0.8rem] opacity-70">◐</span>
              Profile
            </div>
          </div>
        </div>
        <div>
          <div className="mb-4 h-24 w-full rounded-xl bg-gradient-to-br from-[#1c2417] via-[#171a13] to-[#0d0e0b]" />
          <p className="font-display text-[0.95rem] italic leading-snug text-white/60">
            A calmer you, a brighter tomorrow.
          </p>
          <div className="mt-4 flex items-center gap-2 border-t border-white/[0.06] pt-4 text-[0.75rem] text-white/40">
            <span className="flex h-6 w-6 items-center justify-center rounded-full bg-white/10 text-[0.65rem]">B</span>
            Sync across devices
          </div>
        </div>
      </aside>
      <div className="min-w-0 flex-1">{children}</div>
    </div>
  );
}

export function StatChip({ children }: { children: ReactNode }) {
  return (
    <span className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/[0.03] px-3.5 py-1.5 text-[0.78rem] text-white/70">
      {children}
    </span>
  );
}

export function Card({ children, className = "" }: { children: ReactNode; className?: string }) {
  return (
    <div className={`rounded-2xl border border-white/[0.07] bg-white/[0.015] p-6 ${className}`}>{children}</div>
  );
}
