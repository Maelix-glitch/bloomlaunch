import { AppShell, Card } from "./AppShell";

const TRACKS = [
  { label: "Sleep", value: "8h 14m", target: "Target 8h · Avg 7h 25m", color: "#8d7bf2" },
  { label: "Water", value: "2.4L", target: "Target 2.2L · Avg 2.1L", color: "#5fd6d6" },
  { label: "Study", value: "2h 26m", target: "Target 2h · Avg 2h 3m", color: "#5b8ff2" },
  { label: "Movement", value: "37m", target: "Target 30m · Avg 31m", color: "#7fb88f" },
  { label: "Energy", value: "3/5", target: "Target 3/5 · Avg 3/5", color: "#e8b158" },
  { label: "Screen", value: "1h 52m", target: "Target 3h · Avg 2h 29m", color: "#e0607c" },
];

export function TrackersMock() {
  return (
    <AppShell active="Trackers">
      <div className="px-6 py-6 sm:px-10 sm:py-8">
        <p className="text-[0.68rem] uppercase tracking-[0.2em] text-white/35">45 days logged · 6/6 targets today</p>
        <h2 className="mt-2 font-display text-[2.1rem] sm:text-[2.5rem]">Daily metrics at a glance.</h2>
        <p className="mt-2 max-w-lg text-[0.88rem] text-white/50">
          Real data only. Six trackers measured against goals you set. No estimates, no filling in blanks.
        </p>

        <div className="mt-8 flex flex-col gap-8 lg:flex-row">
          <div className="flex shrink-0 justify-center lg:w-64">
            <div className="relative flex h-56 w-56 items-center justify-center rounded-full">
              {TRACKS.map((t, i) => (
                <div
                  key={t.label}
                  className="absolute rounded-full border-2"
                  style={{
                    inset: i * 18,
                    borderColor: t.color,
                    opacity: 0.75,
                    boxShadow: `0 0 12px ${t.color}55`,
                  }}
                />
              ))}
              <div className="z-10 flex flex-col items-center">
                <span className="text-3xl font-semibold">6</span>
                <span className="text-[0.6rem] uppercase tracking-widest text-white/40">of six reached</span>
              </div>
            </div>
          </div>
          <div className="grid flex-1 grid-cols-1 gap-4 sm:grid-cols-2">
            {TRACKS.map((t) => (
              <Card key={t.label} className="!p-5">
                <div className="flex items-center justify-between">
                  <p className="text-[0.95rem]">{t.label}</p>
                  <p className="text-[0.9rem] text-white/70">{t.value}</p>
                </div>
                <svg viewBox="0 0 200 40" className="mt-3 h-9 w-full overflow-visible">
                  <path
                    d="M0 28 C 20 30, 30 12, 50 20 S 90 30, 110 16 S 150 5, 170 18 S 195 28, 200 22"
                    fill="none"
                    stroke={t.color}
                    strokeWidth="2"
                    opacity="0.9"
                  />
                </svg>
                <p className="mt-2 text-[0.68rem] uppercase tracking-wide text-white/35">{t.target}</p>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </AppShell>
  );
}
