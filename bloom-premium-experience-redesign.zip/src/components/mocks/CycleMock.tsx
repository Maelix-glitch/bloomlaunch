import { AppShell } from "./AppShell";

export function CycleMock() {
  return (
    <AppShell active="Cycle">
      <div className="relative overflow-hidden bg-gradient-to-b from-[#241a33] via-[#0c0a10] to-[#08090b] px-6 py-6 sm:px-10 sm:py-8">
        <p className="text-[0.68rem] uppercase tracking-[0.2em] text-white/40">
          Good morning · Bloom cycle intelligence
        </p>
        <h2 className="mt-3 font-display text-[1.9rem] leading-[1.15] text-white sm:text-[2.3rem]">
          Your cycle, read back to you —
          <br />
          <span className="text-bloom-violet">before it happens.</span>
        </h2>
        <p className="mt-4 max-w-xl text-[0.85rem] leading-relaxed text-white/50">
          Log the day a period starts. Predicted dates, your current phase, and what tends to
          help — calculated from your own record and recalculated the moment you change it.
        </p>

        <div className="mt-7 flex items-center justify-between rounded-2xl border border-white/[0.07] bg-white/[0.02] p-6">
          <div>
            <p className="text-[0.68rem] uppercase tracking-[0.2em] text-white/35">Your pattern, in one line</p>
            <p className="mt-2 text-[1.05rem]">Your average cycle is 28.3 days across 5 logged cycles.</p>
            <div className="mt-5 flex gap-10 text-[0.78rem] text-white/40">
              <div>
                <p className="uppercase tracking-widest text-[0.65rem]">Cycle day</p>
                <p className="mt-1 text-[1.3rem] text-white">2 <span className="text-[0.7rem] text-white/40">of 28</span></p>
              </div>
              <div>
                <p className="uppercase tracking-widest text-[0.65rem]">Cycles logged</p>
                <p className="mt-1 text-[1.3rem] text-white">5</p>
              </div>
              <div>
                <p className="uppercase tracking-widest text-[0.65rem]">Avg length</p>
                <p className="mt-1 text-[1.3rem] text-white">28.3<span className="text-[0.7rem] text-white/40">d</span></p>
              </div>
            </div>
          </div>
          <div className="hidden shrink-0 flex-col items-center sm:flex">
            <div className="flex h-24 w-24 items-center justify-center rounded-full ring-4 ring-bloom-violet/70">
              <span className="text-lg font-semibold">100%</span>
            </div>
            <span className="mt-2 text-[0.65rem] uppercase tracking-widest text-bloom-violet">Steady</span>
          </div>
        </div>

        <div className="mt-5 rounded-2xl border border-white/[0.07] bg-white/[0.02] p-6">
          <p className="text-[0.68rem] uppercase tracking-[0.2em] text-white/35">Phase overview</p>
          <h3 className="mt-2 font-display text-[1.35rem]">Day 2 of about 28</h3>
          <p className="mt-1 text-[0.82rem] text-[#e191b3]">Menstrual · started Sep 16, 2026</p>
          <div className="mt-6 flex flex-col items-center gap-8 sm:flex-row">
            <div className="relative flex h-40 w-40 shrink-0 items-center justify-center rounded-full bg-[conic-gradient(from_-90deg,#e191b3_0%,#e191b3_14%,#8d7bf2_14%,#8d7bf2_78%,rgba(255,255,255,0.08)_78%)]">
              <div className="flex h-28 w-28 flex-col items-center justify-center rounded-full bg-[#0c0a10] text-center">
                <span className="text-[0.7rem] uppercase tracking-widest text-[#e191b3]">Menstrual</span>
                <span className="text-3xl font-semibold">2</span>
                <span className="text-[0.65rem] text-white/40">of 28</span>
              </div>
            </div>
            <div className="h-24 flex-1">
              <svg viewBox="0 0 300 90" className="h-full w-full overflow-visible">
                <path d="M0 80 C 40 82, 90 78, 130 40 S 220 8, 300 30" fill="none" stroke="#8d7bf2" strokeWidth="2" opacity="0.8" />
                <path d="M0 82 C 30 84, 60 75, 90 60" fill="none" stroke="#e191b3" strokeWidth="3" />
                <circle cx="0" cy="82" r="5" fill="#f5f5f5" />
                <circle cx="300" cy="30" r="4" fill="#e191b3" />
              </svg>
              <div className="mt-1 flex justify-between text-[0.65rem] text-white/35">
                <span>Day 1</span>
                <span>ovulation ≈ d14</span>
                <span className="text-[#e191b3]">next period</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </AppShell>
  );
}
